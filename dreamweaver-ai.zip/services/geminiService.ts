import { GoogleGenAI, Type } from "@google/genai";
import { GenAIResponse } from "../types";

// Initialize the client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// System instruction to ensure consistent JSON output and RPG behavior
const SYSTEM_INSTRUCTION = `
You are an advanced interactive fiction engine and Dungeon Master. 
Your goal is to weave a compelling narrative based on the user's input.
The user will provide the current context or a starting scenario.
You must output a JSON object containing:
1. 'sceneDescription': A vivid, atmospheric paragraph describing the current situation or outcome of the action. (Language: Russian)
2. 'imagePrompt': A concise English prompt describing the visual scene for an image generator (e.g., "A dark cyberpunk alleyway, neon lights, rain, digital art style").
3. 'options': An array of exactly 3 distinct, short actions the player can take next. (Language: Russian)

Maintain a serious, engaging tone. Adapt to the genre implied by the user.
`;

export const generateStoryTurn = async (
  previousContext: string,
  userAction: string
): Promise<GenAIResponse> => {
  try {
    const model = "gemini-3-flash-preview";
    
    const prompt = `
    Previous Context: ${previousContext}
    User Action/Input: ${userAction}
    
    Continue the story.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sceneDescription: { type: Type.STRING },
            imagePrompt: { type: Type.STRING },
            options: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ["sceneDescription", "imagePrompt", "options"],
        },
      },
    });

    const jsonText = response.text || "{}";
    const data = JSON.parse(jsonText) as GenAIResponse;
    return data;

  } catch (error) {
    console.error("Error generating story:", error);
    throw error;
  }
};

export const generateSceneImage = async (imagePrompt: string): Promise<string> => {
  try {
    // Using gemini-2.5-flash-image for generation as requested/suggested for efficiency
    const model = "gemini-2.5-flash-image";
    
    const response = await ai.models.generateContent({
      model: model,
      contents: imagePrompt,
      config: {
        // No responseMimeType for image generation models in this context usually, 
        // but we handle the output manually.
      }
    });

    // Extract image
    // The response structure for images in the new SDK usually puts the image in parts
    const parts = response.candidates?.[0]?.content?.parts;
    
    if (parts) {
      for (const part of parts) {
        if (part.inlineData && part.inlineData.data) {
          return part.inlineData.data;
        }
      }
    }
    
    throw new Error("No image data found in response");

  } catch (error) {
    console.error("Error generating image:", error);
    // Return a transparent pixel or empty string to not crash UI, 
    // ideally handle error in UI
    return ""; 
  }
};